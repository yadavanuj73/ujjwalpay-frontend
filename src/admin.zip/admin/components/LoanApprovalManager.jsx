import React, { useState, useEffect } from 'react';
import {
    CheckCircle2, XCircle, Clock, Search, RefreshCcw,
    IndianRupee, Building2, User, Phone, Calendar,
    ChevronRight, ExternalLink, ShieldCheck, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { dataService } from '../../services/dataService';

const LoanApprovalManager = () => {
    const [loans, setLoans] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('all');
    const [simulatingId, setSimulatingId] = useState(null);

    const refreshLoans = async () => {
        setLoading(true);
        try {
            const data = await dataService.getLoans();
            setLoans(data);
        } catch (error) {
            console.error("Failed to fetch loans:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        refreshLoans();
    }, []);

    const handleSimulate = async (trackingId, status) => {
        if (!window.confirm(`Simulate ${status.toUpperCase()} for this application?`)) return;

        setSimulatingId(trackingId);
        try {
            const res = await dataService.simulateLoanStatus(trackingId, status);
            if (res.success) {
                alert(res.message);
                refreshLoans();
            } else {
                alert("Action failed: " + res.message);
            }
        } catch (error) {
            alert("Connection error: " + error.message);
        } finally {
            setSimulatingId(null);
        }
    };

    const filteredLoans = loans.filter(loan => {
        const matchesSearch = (loan.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            loan.phone?.includes(searchTerm) ||
            loan.tracking_id?.toLowerCase().includes(searchTerm.toLowerCase()));

        const matchesStatus = filterStatus === 'all' || loan.status?.toLowerCase() === filterStatus.toLowerCase();

        return matchesSearch && matchesStatus;
    });

    const getStatusStyle = (status) => {
        switch (status?.toLowerCase()) {
            case 'approved': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
            case 'rejected': return 'bg-rose-50 text-rose-700 border-rose-100';
            case 'initiated': return 'bg-blue-50 text-blue-700 border-blue-100';
            case 'pending': return 'bg-amber-50 text-amber-700 border-amber-100';
            default: return 'bg-slate-50 text-slate-700 border-slate-100';
        }
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return 'N/A';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header & Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Total Apps</p>
                    <p className="text-3xl font-bold text-slate-900">{loans.length}</p>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 border-l-4 border-emerald-500">
                    <p className="text-emerald-500 text-[10px] font-black uppercase tracking-widest mb-1">Approved</p>
                    <p className="text-3xl font-bold text-slate-900">{loans.filter(l => l.status?.toLowerCase() === 'approved').length}</p>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 border-l-4 border-amber-500">
                    <p className="text-amber-500 text-[10px] font-black uppercase tracking-widest mb-1">Pending</p>
                    <p className="text-3xl font-bold text-slate-900">{loans.filter(l => l.status?.toLowerCase() === 'pending' || l.status?.toLowerCase() === 'initiated').length}</p>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 border-l-4 border-rose-500">
                    <p className="text-rose-500 text-[10px] font-black uppercase tracking-widest mb-1">Rejected</p>
                    <p className="text-3xl font-bold text-slate-900">{loans.filter(l => l.status?.toLowerCase() === 'rejected').length}</p>
                </div>
            </div>

            {/* Controls */}
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="relative w-full md:w-96">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                        type="text"
                        placeholder="Search by name, phone or tracking ID..."
                        className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                    <select
                        className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-bold text-slate-600 outline-none"
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                    >
                        <option value="all">All Status</option>
                        <option value="initiated">Initiated</option>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                    <button
                        onClick={refreshLoans}
                        className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                    >
                        <RefreshCcw size={20} className={loading ? "animate-spin" : ""} />
                    </button>
                </div>
            </div>

            {/* Loan Table */}
            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-50 text-slate-400 font-bold text-[10px] uppercase tracking-widest">
                                <th className="px-8 py-5">Customer Info</th>
                                <th className="px-8 py-5">Tracking ID</th>
                                <th className="px-8 py-5">Status</th>
                                <th className="px-8 py-5">Offer Details</th>
                                <th className="px-8 py-5">Actions (Simulate)</th>
                                <th className="px-8 py-5 text-right">Last Update</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {loading ? (
                                Array(5).fill(0).map((_, i) => (
                                    <tr key={i} className="animate-pulse">
                                        <td colSpan="6" className="px-8 py-10 border-b">
                                            <div className="h-4 bg-slate-100 rounded w-full"></div>
                                        </td>
                                    </tr>
                                ))
                            ) : filteredLoans.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="px-8 py-20 text-center">
                                        <div className="flex flex-col items-center gap-2 opacity-30">
                                            <AlertCircle size={48} />
                                            <p className="font-bold uppercase tracking-widest">No loan applications found</p>
                                        </div>
                                    </td>
                                </tr>
                            ) : filteredLoans.map((loan) => (
                                <tr key={loan.app_id} className="hover:bg-slate-50/50 transition-colors group">
                                    <td className="px-8 py-6">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs">
                                                {loan.name?.substring(0, 2).toUpperCase()}
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-900">{loan.name}</p>
                                                <p className="text-[10px] text-slate-400 font-medium">{loan.phone}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-8 py-6">
                                        <span className="font-mono text-[11px] text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
                                            {loan.tracking_id}
                                        </span>
                                    </td>
                                    <td className="px-8 py-6">
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tight border ${getStatusStyle(loan.status)}`}>
                                            {loan.status}
                                        </span>
                                    </td>
                                    <td className="px-8 py-6">
                                        {loan.offer_amount ? (
                                            <div className="flex flex-col">
                                                <span className="text-sm font-black text-slate-900">₹{parseFloat(loan.offer_amount).toLocaleString('en-IN')}</span>
                                                <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-tighter">
                                                    {loan.lender_name} • {loan.interest_rate}
                                                </span>
                                            </div>
                                        ) : (
                                            <span className="text-[10px] text-slate-300 italic font-medium">Awaiting response...</span>
                                        )}
                                    </td>
                                    <td className="px-8 py-6">
                                        <div className="flex items-center gap-2">
                                            <button
                                                disabled={simulatingId === loan.tracking_id}
                                                onClick={() => handleSimulate(loan.tracking_id, 'approved')}
                                                className="p-2 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-600 hover:text-white transition-all shadow-sm disabled:opacity-50"
                                                title="Approve (Simulate)"
                                            >
                                                <CheckCircle2 size={18} />
                                            </button>
                                            <button
                                                disabled={simulatingId === loan.tracking_id}
                                                onClick={() => handleSimulate(loan.tracking_id, 'rejected')}
                                                className="p-2 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-600 hover:text-white transition-all shadow-sm disabled:opacity-50"
                                                title="Reject (Simulate)"
                                            >
                                                <XCircle size={18} />
                                            </button>
                                        </div>
                                    </td>
                                    <td className="px-8 py-6 text-right">
                                        <p className="text-[11px] font-bold text-slate-700">{formatDate(loan.updated_at).split(',')[0]}</p>
                                        <p className="text-[9px] text-slate-400 font-black uppercase tracking-tighter">{formatDate(loan.updated_at).split(',')[1]}</p>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default LoanApprovalManager;
